function validar() {
    var nome = document.getElementById("nome").value;
    var idade = document.getElementById("idade").value;
    var salario = document.getElementById("salario").value;
    var sexo = document.getElementById("sexo").value;
    var estadoCivil = document.getElementById("estado-civil").value;

    var errorNome = document.getElementById("error-nome");
    var errorIdade = document.getElementById("error-idade");

}